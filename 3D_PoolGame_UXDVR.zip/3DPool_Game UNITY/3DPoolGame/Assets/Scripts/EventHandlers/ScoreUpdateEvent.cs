﻿
namespace ThreeDPool.EventHandlers
{
    public class ScoreUpdateEvent : IGameEvent
    {
    }
}
