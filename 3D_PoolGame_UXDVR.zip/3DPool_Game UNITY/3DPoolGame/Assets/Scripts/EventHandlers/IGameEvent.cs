﻿
namespace ThreeDPool.EventHandlers
{
    public interface IGameEvent
    {
    }
}
