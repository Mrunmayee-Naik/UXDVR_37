﻿
namespace ThreeDPool.EventHandlers
{
    // this event system will be helpful for UI implementation
    public struct CueActionEvent : IGameEvent
    {
        public float ForceGathered; 
    }
}
