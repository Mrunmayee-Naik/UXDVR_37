﻿using UnityEngine;

namespace ThreeDPool.Controllers
{
    public class AIController : MonoBehaviour
    {
    }
}
