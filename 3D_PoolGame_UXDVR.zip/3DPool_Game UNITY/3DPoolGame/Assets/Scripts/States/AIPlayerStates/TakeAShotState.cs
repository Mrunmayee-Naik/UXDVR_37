﻿using System;

namespace ThreeDPool.States
{
    public class TakeAShotState : IState
    {
        public void OnEnter()
        {
        }

        public void OnExit()
        {
        }

        public void OnUpdate()
        {
        }
    }
}
