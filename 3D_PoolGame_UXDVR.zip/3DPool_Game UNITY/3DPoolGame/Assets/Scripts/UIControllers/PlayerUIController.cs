﻿using UnityEngine;
using UnityEngine.UI;
namespace ThreeDPool.UIControllers
{
    public class PlayerUIController : MonoBehaviour
    {
        public Text NameNScore;
        public Image TurnMarker;
    }
}
